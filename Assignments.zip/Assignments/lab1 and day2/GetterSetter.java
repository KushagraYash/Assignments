package assignments;

public class GetterSetter
{
	    private int number;
		 
		    public int getNumber()
		    {
		        return this.number;
		    }
		 
		    public void setNumber(int num)
		    {
		        this.number = num;
		    }
}