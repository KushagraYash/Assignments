package assignments;

public class Calculator {

	public Integer calculate(String strinng) {
		// TODO Auto-generated method stub
			return 0;
	}

}
