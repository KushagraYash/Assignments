package com.yash.Inhr_polyQ2;

public class Yorkshire extends Dog
{

	@Override
	void speak()
	{
		System.out.println("I am of Yorkshire breed");
	}

	@Override
	void avgBreedWeight() 
	{
		System.out.println("Avg Breed Weight of Yorkshire is 3.5KG");
		
	}
	

}
