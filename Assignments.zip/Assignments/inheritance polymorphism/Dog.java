package com.yash.Inhr_polyQ2;

public abstract class Dog
{
	abstract void speak();
	abstract void avgBreedWeight();

}
