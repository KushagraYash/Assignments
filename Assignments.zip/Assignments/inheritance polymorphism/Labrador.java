package com.yash.Inhr_polyQ2;

public class Labrador extends Dog
{

	@Override
	void speak() {
		System.out.println("I am of Labrador Breed");
	}

	@Override
	void avgBreedWeight() {
		System.out.println("Avg Breed weight of Labrador is 2.5KG");
	}
	
}
