package collections;

public class Customer {
long id;
String name;
int product_Quantity;
public Customer(long id,String name,int product_Quantity) {
	super();
	this.id=id;
	this.name=name;
	this.product_Quantity=product_Quantity;
}
@Override

public String toString() {
	return "\n\tCustomer id= " +id+"\nname= "+name+"\tproduct_Quantity= "+product_Quantity;
	
}
}
