package collections;
import java.util.*;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class DequeExample {
	// Java program to demonstrate the working of a Deque in Java
	public static void main(String[] args)
	{
		Deque<String> deque = new LinkedList<String>();

		// We can add elements in various ways

		// Add at the last
		deque.add("Element 1 (Tail)");

		// Add at the first
		deque.addFirst("Element 2 (Head)");

		// Add at the last
		deque.addLast("Element 3 (Tail)");

		// Add at the first
		deque.push("Element 4 (Head)");

		// Add at the last
		deque.offer("Element 5 (Tail)");

		// Add at the first
		deque.offerFirst("Element 6 (Head)");
		System.out.println(deque + "\n");

		//it removes first element
		// System.out.println(deque.pop());
		// System.out.println(deque.poll());
		// System.out.println(deque.pollFirst());
		// System.out.println(deque.pollLast());
		// System.out.println(deque + "\n");

		// We can remove the first element
		deque.removeFirst();
		System.out.println("Deque after removing first: "+ deque);

		// or the last element.
		deque.removeLast();
		System.out.println("Deque after removing last: \n"+ deque);


		//  deque.add("Brijmohan");
		//  deque.addFirst("Kushagra");
		//  deque.addLast("Sharma");
		//  System.out.println(deque + "\n");
	}
}







//https://www.geeksforgeeks.org/deque-interface-java-example/