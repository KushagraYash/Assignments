package collections;
import java.util.*;  
/**
 * collection program for push and pop an object
 * @author kushagra.sharma
 *
 */
public class PushPop {
	public static void main(String args[])
	{  
	
	Stack<String> item = new Stack<String>();  
	item.push("Shirt");  
	item.push("tShirt");  
	item.push("Jeans");  
	item.push("Jacket");  
	item.push("Hoodie");  
	
	item.pop();  
	
	Iterator<String> itr=item.iterator();  
	
	while(itr.hasNext())
	{  
	System.out.println(itr.next());  
	}  
	}  
	}  
