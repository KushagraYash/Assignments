package collections;
import java.util.LinkedList;

public class CustomerApp {

	public static void main(String[] args) {
		/*HashSet<String> h=new HashSet<String>();
		h.add("Python");
		h.add("Ruby");
		h.add("Java");
		h.add("Swift");
		System.out.println(h);
		 */
		/*	HashSet<Customer> h1=new HashSet<Customer>();
		h1.add(new Customer(1,"Allen",11));
		h1.add(new Customer(2,"Andrew",12));
		h1.add(new Customer(1,"Allen",11));
		h1.add(new Customer(3,"John",12));

		System.out.println(h1);
		 */

		LinkedList<Customer> h1=new LinkedList<Customer>();
		h1.add(new Customer(4,"Mazekene",14));
		h1.add(new Customer(1,"Allen",11)); //this and
		h1.add(new Customer(2,"Cloe",12));
		h1.add(new Customer(1,"Allen",11)); //this are same
		h1.add(new Customer(3,"Emanedeil",13));

		//	System.out.println(h1);
		h1.remove(1);  //remove() first entry by default
						//and remove(3) remove by indexing
		h1.addLast(new Customer(5,"kushagra",55));
		
		h1.addFirst(new Customer(0,"ALucifer",0));
		
		h1.set(1, new Customer(8,"angel",61));
		System.out.println(h1);
		
	
		}

}
