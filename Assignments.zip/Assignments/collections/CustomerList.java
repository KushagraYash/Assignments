package collections;
import java.util.*;  
/**
 * 
 * @author kushagra.sharma
 *
 */

public class CustomerList 
{
	public static void main(String args[])
	{  

		ArrayList<String> list=new ArrayList<String>();     //Creating arraylist  
		list.add("Fruits");     //Adding object in arraylist  
		list.add("Flowers");  
		list.add("Milk");  
		list.add("Curd"); 
		list.listIterator();
		

		//Traversing list through Iterator  

		Iterator<String> itr=list.iterator();  

		while(itr.hasNext()){  

			System.out.println(itr.next());  
		}  
	}  
}  

