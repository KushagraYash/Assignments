package collections;
import java.util.*;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class EmptyList {

	@SuppressWarnings("rawtypes")
	
	public static void main(String[]args)
	{
	
		int id;String name;double per;long fee; boolean m;char grade;
	
	ArrayList<Comparable> details= new ArrayList<Comparable>();
	details.add(id=21);			//Student ID
	details.add(name="Kushagra");	//Student name
	details.add(per=80.66);			//Student percentage
	details.add(fee=450000);		//Student Total Fees
	details.add(m=true);			//Student passed
	details.add(grade='A');			//Student grade
	
	System.out.println("Student ID:- "+id+"\nStudent name:- "+name+"\nStudent percentage:- "+per+
			"\nStudent Total Fees:- "+fee+"\nStudent passed:- "+m+"\nStudent grade:- "+grade);

	
	details.remove(0);
	System.out.println(details);
	/*
	details.add(21);			//Student ID
	details.add("Kushagra");	//Student name
	details.add(80.66);			//Student percentage
	details.add(450000);		//Student Total Fees
	details.add(true);			//Student passed
	details.add('A');			//Student grade
	
	System.out.println(details);
	*/
	}
	}

