package patterns_assignment;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class patternAadhar {
	
public static boolean isValidAadharNo(String AC)
	    {
	        
	        String regex = "^[2-9]{1}[0-9]{3}\\-[0-9]{4}\\-[0-9]{4}$";
	      
	        Pattern p = Pattern.compile(regex);
	        if (AC == null) 
	        {
	            return false;
	        }
	        Matcher m = p.matcher(AC);
	        return m.matches();
	    }

	    public static void main(String args[])
	    {
	 
	       
	        String AC1 = "3646-2598-7893";
	        System.out.println(isValidAadharNo(AC1));
	 
	        
	        String AC2 = "36461-2598-7893";
	        System.out.println(isValidAadharNo(AC2));
	 
	        
	        String AC3 = "364-2598-7893";
	        System.out.println(isValidAadharNo(AC3));
	 
	       
	        String AC4 = "0646-2598-7893";
	        System.out.println(isValidAadharNo(AC4));
	 
	      
	        String AC5 = "3646-02598-789";
	        System.out.println(isValidAadharNo(AC5));
	    }
	

}
