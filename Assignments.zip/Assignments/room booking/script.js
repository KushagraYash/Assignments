function myFunction(val) 
{
    document.write("The input value has changed. The new value is: " + val);
  }
  
  
function displayDate() {
  document.getElementById("demo").innerHTML = Date();
}