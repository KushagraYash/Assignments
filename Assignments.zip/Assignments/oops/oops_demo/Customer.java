package com.yash.oops_demo;

public class Customer {

	public void getDetails() {
		// TODO Auto-generated method stub
		
	}

}
