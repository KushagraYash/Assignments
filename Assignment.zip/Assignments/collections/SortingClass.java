package collections;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
/**
 * used to sort elements
 * @author kushagra.sharma
 *
 */

public class SortingClass {

	public static void main(String args[]) {

	// Creating and initializing an LinkedList for sorting
	LinkedList<String> sorted = new LinkedList<>();
	sorted.add("Cloe");
	sorted.add("Lucifer");
	sorted.add("Kushagra");
	sorted.add("Amenadiel");
	sorted.add("Linda");
	sorted.add("Akshay");

	System.out.println("LinkedList before: \n" + sorted);

	// Example 1 - Sorting LinkedList with Collections.sort() method 
	// in natural order
	Collections.sort(sorted);
	
	System.out.println("\nAfter sorting by format: \n"+sorted);

	// Example 2 - Sorting LinkedList using Collection.sort() and Comparator in Java
	Collections.sort(sorted, new Comparator<String>() {
	@Override
	public int compare(String s1, String s2) {
	return s1.length() - s2.length();
	} } );

	System.out.println("\nAfter Sort: \n" + sorted);
	}
	
}
//@Overridepublic int compareTo(Customer obj) {
//    return this.name.compareTo(obj.name);
//}