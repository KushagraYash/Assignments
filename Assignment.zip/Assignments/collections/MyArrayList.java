package collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * 
 * @author kushagra.sharma
 *
 */

public class MyArrayList {

	public static void main(String[] args) {

		// create a list using of <genereric collection> type of list, 
		List<String> list = Arrays.asList("Shirt", "Jeans");

		// alternate		
		List<String> anotherList = new ArrayList<>();
		anotherList.add("T-Shirt");
		anotherList.add("Jeans");

		// print each element to the console using method references
		list.forEach(System.out::println);
		anotherList.forEach(System.out::println);
	}
}