package com.yash.oops_demo;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class Customer {

	public void getDetails() {
		// TODO Auto-generated method stub
		
	}

}
