package com.yash.bank;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class Hdfc extends Bank
{
	final int depositeMoney=1500;
	int getBalance()
	{
		return depositeMoney;
		
	}
}
