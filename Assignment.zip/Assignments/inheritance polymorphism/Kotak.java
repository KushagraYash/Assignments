package com.yash.bank;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class Kotak extends Bank
{
	final int depositeMoney=2000;
	int getBalance()
	{
		return depositeMoney;
		
	}
}
