package com.yash.bank;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class Bank 
{
	 int getBalance()
	 {
		 return 0;
	 }
	
}
