package com.yash.bank;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class Sbi extends Bank
{
	final int depositeMoney=1000;
	int getBalance()
	{
		return depositeMoney;
		
	}
}
