package com.yash.dogs;
/**
 * 
 * @author kushagra.sharma
 *
 */
public abstract class Dog 
{
	abstract int avgBreedWeight();
}
