package com.yash.calculator;
/**
 * 
 * @author kushagra.sharma
 *
 */
public interface Calculator
{
	public int square(); 
}
