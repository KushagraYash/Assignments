package com.yash.Inhr_polyQ1;

/**
 * 
 * @author kushagra.sharma
 *
 */
public class EmployeeMain 
{
    public static void main( String[] args )
    {
    	Employee e= new Employee("Sanjay",25000, 2021,"SWE1234");
        System.out.println(e);
    }
}
