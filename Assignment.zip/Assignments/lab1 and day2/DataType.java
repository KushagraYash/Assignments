package assignments;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class DataType {

	
			public static void main(String arg[])
			{
				System.out.println(" Maximum and minimum range of primitive data types in JAVA");
				
				System.out.println("MAximum value of Byte:"+Byte.MAX_VALUE);
				System.out.println("Minimum value of Byte:"+Byte.MIN_VALUE);
				
				System.out.println("MAximum value of Short:"+Short.MAX_VALUE);
				System.out.println("Minimum value of Short:"+Short.MIN_VALUE);
							
				System.out.println("MAximum value of Integer:"+Integer.MAX_VALUE);
				System.out.println("Minimum value of Integer:"+Integer.MIN_VALUE);
				
				System.out.println("MAximum value of Float:"+Float.MAX_VALUE);
				System.out.println("Minimum value of Float:"+Float.MIN_VALUE);
				
				System.out.println("MAximum value of Double:"+Double.MAX_VALUE);
				System.out.println("Minimum value of Double:"+Double.MIN_VALUE);
				
				System.out.println("MAximum value of Long:"+Long.MAX_VALUE);
				System.out.println("Minimum value of Long:"+Long.MIN_VALUE);
				
						
			}
	}

