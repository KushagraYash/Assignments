package com.oops;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class StringPattern
{

	public static void main(String args[])
	{
		String st = "one 9two4 three7 four1five";
		System.out.println();

		String st1=st.replaceAll("[^A-Za-z]", "");
		String st2=st.replaceAll("[^0-9]", "");
	}
}