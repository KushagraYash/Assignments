package patterns_assignment;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class patternPassword 
{

	private static boolean checkPassword(String str) 
	{
		String regex="^[A-S](?=.*?[a-z])(?=.*?[0-9])(?=.*?[#$]).{8,}$";
		//String regex="^[A-S]{1}"+ "2(module)(.+){2}"+"[a-z]"+"[1]\\Z$";
		//String regex="^[A-S](?=.*[a-z])(?=.*[#$])[1].{5,12}$";
		
		Pattern p = Pattern.compile(regex);

		if(str == null)
		{
			return false;
		}

		Matcher m=p.matcher(str);
		return m.matches();
	}

	public static void main(String args[])
	{
		String str1="K$U24#sh1";
		System.out.println(checkPassword(str1));
		String str2="kushA12#@Gra";
		System.out.println(checkPassword(str2));
		String str3="K2#agfra1";
		System.out.println(checkPassword(str3));
		String str4="uassword#$99";
		System.out.println(checkPassword(str4));
		String str5="$kuSH3agra#";
		System.out.println(checkPassword(str5));
	}
}
