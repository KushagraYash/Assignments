package com.yash.ExceptionHandling;
/**
 * 
 * @author kushagra.sharma
 *
 */
public class ProductApp 
{
	int ProductId;
	String ProductName;
	double ProductPrice;
	public String toString()
	{
		return "ProductApp[ product id:"+ProductId+",product name:"+ProductName+""
				+ ",product price:"+ProductPrice+"]";
	}
}
